@echo off
setlocal
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if exist "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" (
 echo Microsoft .NET Framework C# compiler not found.
 echo START_FHD_SETUP.cmd is still available without compiling.
 pause
 exit /b 1
)
"%CSC%" /nologo /target:winexe /optimize+ /r:System.Windows.Forms.dll /out:"%~dp0FHD_Mods_Setup.exe" "%~dp0installer\FHD_Launcher.cs"
if errorlevel 1 (
 echo Compile failed.
 pause
 exit /b 1
)
echo FHD_Mods_Setup.exe created successfully.
pause
